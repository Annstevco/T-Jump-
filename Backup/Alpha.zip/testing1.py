import pygame
from pygame.locals import *
import sys      

pygame.init()
screen = pygame.display.set_mode((800, 600), 0, 32) #Screen resolution
running = True
score = 0
font1 = pygame.font.SysFont("Arial", 30)
font2 = pygame.font.SysFont("Arial", 20)
click = False


def drawtext(text, font, color, x, y):
    textobj = font.render(text, 1, color)
    textrect = textobj.get_rect()
    textrect.topleft = (x,y)
    screen.blit(textobj, textrect)
    #print('Run')

def gameover():
    while running:
        mx, my = pygame.mouse.get_pos() #Mouse pointer coordinates (x, y)
        screen.fill((0,0,0))
        
        #Score box
        pygame.draw.line(screen, (222,222,222), (291, 251), (539, 251)) #Horizontal line (Below)
        pygame.draw.line(screen, (222,222,222), (291, 195), (539, 195)) #Horizontal line (Above)
        pygame.draw.line(screen, (222,222,222), (291, 251), (291, 195)) #Vertical line (Left side)
        pygame.draw.line(screen, (222,222,222), (539, 251), (539, 195)) #Vertical line (Right side)
        drawtext('Score = 9999999', font1, (255,255,255), 300, 208) #Text score
        #End Sbox 

        #Question box
        drawtext('Retry ?', font1, (255,255,255), 364, 258)
        drawtext('Yes', font2, (255,255,255), 322, 318)
        drawtext('No', font2, (255,255,255), 472, 318)
        #End Qbox

        #Making a button for collide point (Rectangle)
        # rumus => pygame.Rect (x, y, width, height)
        button_1 = pygame.Rect(322, 318, 40, 20)
        button_2 = pygame.Rect(472, 318, 30, 20)
        #End of button

        #Collide detection
        if button_1.collidepoint((mx, my)):
            drawtext('Yes', font2, (155,155,155), 322, 318) #High light button if mouse colliding with text (rect in text)
            if click:
                print('Button 1 pressed')
        if button_2.collidepoint((mx, my)):
            drawtext('No', font2, (155,155,155), 472, 318)
            if click:
                print('Button 2 pressed')
        #End of collide detection

        #Delete "#" to see the rectangle
        #pygame.draw.rect(screen, (255, 0, 0), button_1)
        #pygame.draw.rect(screen, (255, 0, 0), button_2)

        click = False
        #print (mx, " -- ", my) #Printing coordinates x and y
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == MOUSEBUTTONDOWN:
                click = True
        pygame.display.update()

gameover()