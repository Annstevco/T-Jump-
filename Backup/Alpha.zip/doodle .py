import pygame
from pygame.locals import *
import sys
import random
import os 
from abc import ABC, abstractmethod

pygame.font.init()
font1 = pygame.font.SysFont("Arial", 30)
font2 = pygame.font.SysFont("Arial", 20)
running = True
screen = pygame.display.set_mode((800, 600))
font = pygame.font.SysFont("Arial", 25) #global (outside)

def loadimg(filename): #used for load image file 
    path = os.path.dirname(os.path.realpath(__file__))
    iconpath = path+f'/{filename}.png'
    skin = pygame.image.load(str(iconpath))
    skin = pygame.transform.scale(skin, (100, 100))
    return skin

def drawtext(text, font, color, x, y):
    textobj = font.render(text, 1, color)
    textrect = textobj.get_rect()
    textrect.topleft = (x,y)
    screen.blit(textobj, textrect)

def gameover():
    click = False
    while running:
        global Jumper
        mx, my = pygame.mouse.get_pos() #Mouse pointer coordinates (x, y)
        screen.fill((0,0,0))
        
        pygame.draw.line(screen, (222,222,222), (291, 251), (539, 251)) #Horizontal line (Below)
        pygame.draw.line(screen, (222,222,222), (291, 195), (539, 195)) #Horizontal line (Above)
        pygame.draw.line(screen, (222,222,222), (291, 251), (291, 195)) #Vertical line (Left side)
        pygame.draw.line(screen, (222,222,222), (539, 251), (539, 195)) #Vertical line (Right side)
        drawtext(f'Score = {Jumper.score}', font1, (255,255,255), 300, 208) #Text score

        drawtext('Retry ?', font1, (255,255,255), 364, 258)
        drawtext('Yes', font2, (255,255,255), 322, 318)
        drawtext('No', font2, (255,255,255), 472, 318)

        button_1 = pygame.Rect(322, 318, 40, 20)
        button_2 = pygame.Rect(472, 318, 30, 20)

        if button_1.collidepoint((mx, my)):
            drawtext('Yes', font2, (155,155,155), 322, 318) #High light button if mouse colliding with text (rect in text)
            if click:
                Pijakan.platforms = [[400, 500, 10, 10]] #pijakan awal
                print('Button 1 pressed')
                Jumper = Player()

                run()

        if button_2.collidepoint((mx, my)):
            drawtext('No', font2, (155,155,155), 472, 318)
            if click:
                print('Button 2 pressed')
                pygame.quit()
                sys.exit()

        click = False
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == MOUSEBUTTONDOWN:
                click = True
        pygame.display.update()

def drawPlatforms():
        for p in Pijakan.platforms:
            check = Pijakan.platforms[1][1] - Jumper.cameray
            if check > 600:
                platform = random.randint(0, 1000)
                if platform < 800:
                    platform = 0
                elif platform < 900:
                    platform = 1
                else:
                    platform = 2

                Pijakan.platforms.append([random.randint(0, 700), Pijakan.platforms[-1][1] - 50, platform, 0])
                coords = Pijakan.platforms[-1]
                check = random.randint(0, 1000)
                Pijakan.platforms.pop(0)
                Jumper.score += 100
            if p[2] == 0:
                screen.blit(PijakanAsli.asli, (p[0], p[1] - Jumper.cameray))
            elif p[2] == 1:
                screen.blit(PijakanSekali.sekali, (p[0], p[1] - Jumper.cameray))
            elif p[2] == 2:
                if not p[3]:
                    screen.blit(PijakanJebakan.Jebakan, (p[0], p[1] - Jumper.cameray))

def updatePlayer():
        if not Jumper.jump:
            Jumper.playery += Jumper.gravity
            Jumper.gravity += 0.4
        elif Jumper.jump:
            Jumper.playery -= Jumper.jump
            Jumper.jump -= 1
        key = pygame.key.get_pressed()
        if key[K_RIGHT]:
            if Jumper.direction == 1:
                Jumper.player = pygame.transform.flip(Jumper.player, True,False) #Mirror the skin    
            if Jumper.xmovement < 3:
                Jumper.xmovement += 1
            Jumper.direction = 0 # 0 -> Right
        elif key[K_LEFT]:
            if Jumper.direction == 0:
                Jumper.player = pygame.transform.flip(Jumper.player, True,False) #Mirror the skin
            if Jumper.xmovement > -3:
                Jumper.xmovement -= 1
            Jumper.direction = 1 # 1 -> Left
        
        # To make player stay still when no button pressed
        else:
            if Jumper.xmovement > 0:
                Jumper.xmovement -= 1
            elif Jumper.xmovement < 0:
                Jumper.xmovement += 1

        #WRAPPING PLAYER 
        if Jumper.playerx > 760:
            Jumper.playerx = -50
        elif Jumper.playerx < -50:
            Jumper.playerx = 760
        Jumper.playerx += Jumper.xmovement
        if Jumper.playery - Jumper.cameray <= 200:
            Jumper.cameray -= 10

        screen.blit(Jumper.player, (Jumper.playerx, Jumper.playery - Jumper.cameray))  

def generatePlatforms():
    on = 600
    while on > -100:
        x = random.randint(0,700)
        platform = random.randint(0, 1000)
        if platform < 800:
            platform = 0
        elif platform < 900:
            platform = 1
        else:
            platform = 2
        Pijakan.platforms.append([x, on, platform, 0])
        on -= 50

class Player:
    def __init__(self):
        self.player = loadimg("kiri") #player
        self.direction = 1 #player
        self.playerx = 400 #player
        self.playery = 400 #player
        self.cameray = 0
        self.jump = 0
        self.gravity = 0
        self.xmovement = 0
        self.hp = 1 #Not implemented yet
        self.score = 0 #player
    def MoveRight(self):
        if self.direction == 1:
            self.player = pygame.transform.flip(self.player, True,False) #Mirror the skin    
        if self.xmovement < 10:
            self.xmovement += 5
        self.direction = 0 # 0 -> Right
        self.checkboundaries()
    def MoveLeft(self):
        if self.direction == 0:
            self.player = pygame.transform.flip(self.player, True,False) #Mirror the skin
        if self.xmovement > -10:
            self.xmovement -= 5
        self.direction = 1 # 1 -> Left
        self.checkboundaries()
    def TakeDamage(self):
        pass
    def Jump(self):
        if not self.jump:
            self.playery += self.gravity
            self.gravity += 0.4
        elif self.jump:
            self.playery -= self.jump
            self.jump -= 1
    def checkboundaries(self):
        if self.playerx > 760:
            self.playerx = -50
        elif self.playerx < -50:
            self.playerx = 760
        self.playerx += self.xmovement
        if self.playery - self.cameray <= 200:
            self.cameray -= 10
        screen.blit(self.player, (self.playerx, self.playery - self.cameray))
    def checkcollision(self):
        self.Jump()
        for p in Pijakan.platforms:
            rect = pygame.Rect(p[0], p[1], PijakanAsli.asli.get_width() -5, PijakanAsli.asli.get_height())
            player = pygame.Rect(self.playerx, self.playery, self.player.get_width() -10, self.player.get_height())
            if rect.colliderect(player) and self.gravity and self.playery < (p[1] - self.cameray):
                if p[2] != 2:
                    self.jump = 15
                    self.gravity = 0
                    self.Jump()
   
class Pijakan(ABC):
    platforms = [[400, 500, 10, 10]] #pijakan awal
    def __init__(self, damage):
        self.Damage = damage
    @abstractmethod
    def Move():
        pass
    @abstractmethod
    def GiveDamage(self):
        pass
    @abstractmethod
    def Dissapear(self):
        pass 
class PijakanAsli(Pijakan):
    asli = loadimg("asli") #pijakan
    def __init__(self, damage):
        super().__init__(damage)
    def Move(self):
        pass
    def GiveDamage(self):
        pass
    def Dissapear(self):
        pass 
class PijakanSekali(Pijakan):
    sekali = loadimg("sekali") #pijakan
    def __init__(self, damage):
        super().__init__(damage)
    def Move():
         for p in Pijakan.platforms:
            if p[2] == 1:
                if p[-1] == 1:
                    p[0] += 5
                    if p[0] > 550:
                        p[-1] = 0
                else:
                    p[0] -= 5
                    if p[0] <= 0:
                        p[-1] = 1
    def GiveDamage(self):
        pass
    def Dissapear(self):
        pass 
class PijakanJebakan(Pijakan):
    Jebakan = loadimg("jebakan") #pijakan
    def __init__(self, damage):
        super().__init__(damage)
    def Move():
        pass
    def GiveDamage(self):
        pass
    def Dissapear(self):
        pass 


Jumper = Player()
def run():
    clock = pygame.time.Clock()
    generatePlatforms()
    while True:
        screen.fill((255,255,255))
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            """
            """
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    print('key pressed')
                    Jumper.MoveLeft()
                elif event.key == pygame.K_RIGHT:
                    print('key pressed')
                    Jumper.MoveRight()
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_RIGHT or event.key == pygame.K_LEFT:
                    print('no key')
                    """
                    if Jumper.xmovement > 0:
                        Jumper.xmovement -= 1
                    elif Jumper.xmovement < 0:
                        Jumper.xmovement += 1
                    """
                    Jumper.xmovement = 0
        if Jumper.playery - Jumper.cameray > 700:
            gameover()
        #updatePlayer()
        drawPlatforms()
        #key = pygame.key.get_pressed()
        Jumper.checkcollision()
        Jumper.checkboundaries()
        PijakanSekali.Move()
        #updatePlatforms()
        #screen.blit(Jumper.player, (Jumper.playerx, Jumper.playery - Jumper.cameray))
        screen.blit(font.render(str(Jumper.score), -1, (0, 0, 0)), (25, 25))
        pygame.display.flip()
        

run()
